# Netflix Show Movies Data Visualization

- This is a Python program for cleaning and visualizing the Netflix dataset

- Here’s how to get the project running on your local system

### Requirements

- Python 3.x
- Jupyter Notebook 
- R or Rstudio

### Usage

The project consists of several files:

- `Netflix_shows_analysis.ipynb`: Contains the majority of the code analysis.
- `nexflix_data.zip`: Contains the zip file
- `most_watched.png`: Contains the image integrated into R.
- `most_watched.R`: Contains the R code used to display the imported chart.


### Instructions

- Unzip the zipped netflix data set 
- Rename the file to `Nexflix_shows_movies`
- Open the `Nexflix_shows_analysis.ipynb` file
- Load the CSV file and remove missing values to ensure accurate data representation.
- Display the first 20 rows of the dataset.
- Perform descriptive analysis, including calculations like mean, standard deviation.
- Retrieve information about the dataset, such as the number of columns and rows.
- Visualize the most-watched genre using the Seaborn and Plotly libraries.
- Visualize the rating distribution with Seaborn and Plotly.
- Save the most watched plot as most_watched.png.
- Open the R script named most_watched.R.
- Load the required png and grid packages in R.
- Load the image file path generated in Python.
- Note: Adjust the file path to match your computer's directory structure.
- Finally, display the chart in R.



